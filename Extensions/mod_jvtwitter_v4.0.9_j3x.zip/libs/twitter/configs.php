<?php
/**
# mod_jvtwitter - JV Twitter
# @version		3.0
# ------------------------------------------------------------------------
# author    Open Source Code Solutions Co
# copyright Copyright (C) 2011 joomlavi.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL or later.
# Websites: http://www.joomlavi.com
# Technical Support:  http://www.joomlavi.com/my-tickets.html
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
define('JVTWITTER_API', 'P1ua0VEC16Uo8y8LuTbdZg');
define('JVTWITTER_SECRET', 'BFmAZ61TOX7YBhTsf85B2lunCpQUI3oBkyKHmVWIgQ');