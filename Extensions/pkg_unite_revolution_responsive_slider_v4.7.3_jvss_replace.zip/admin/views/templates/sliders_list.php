
	<table class='wp-list-table widefat fixed unite_table_items'>
		<thead>
			<tr>
				<th width='20px'><?php _uge("ID",REVSLIDER_TEXTDOMAIN)?></th>
				<th width='25%'><?php _uge("Name",REVSLIDER_TEXTDOMAIN)?></th>
				<th width='70px'><?php _uge("N. Slides",REVSLIDER_TEXTDOMAIN)?></th>						
				<th width='50%'><?php _uge("Actions",REVSLIDER_TEXTDOMAIN)?> </th>
			</tr>
		</thead>
		<tbody>
			<?php
			if($outputTemplates)
				$useSliders = $arrSlidersTemplates;
			else
				$useSliders = $arrSliders;
			
			
			foreach($useSliders as $slider):
				try{
					$id = $slider->getID();
					$showTitle = $slider->getShowTitle();
					$title = $slider->getTitle();
					$alias = $slider->getAlias();
					$isFromPosts = $slider->isSlidesFromPosts();
										
					$rowClass = "";					
					if($isFromPosts == true){
						$strSource = __ug("Posts",REVSLIDER_TEXTDOMAIN);
						$preicon ="revicon-doc";
						$rowClass = "class='row_alt'";
					}
					
					if($outputTemplates){
						$editLink = self::getViewUrl(RevSliderAdmin::VIEW_SLIDER_TEMPLATE,"id=$id");
					}else{
						$editLink = self::getViewUrl(RevSliderAdmin::VIEW_SLIDER,"id=$id");
					}
					$editSlidesLink = self::getViewUrl(RevSliderAdmin::VIEW_SLIDES,"id=$id");
					
					$showTitle = UniteFunctionsRev::getHtmlLink($editLink, $showTitle);
					
					$numSlides = $slider->getNumSlides();
					
					
				}catch(Exception $e){					
					$errorMessage = "ERROR: ".$e->getMessage();
					$strSource = "";
					$numSlides = "";
				}
				
			?>
				<tr <?php echo $rowClass?>>
					<td><?php echo $id?><span id="slider_title_<?php echo $id?>" class="hidden"><?php echo $title?></span></td>								
					<td>
						<?php echo $showTitle?>
						<?php if(!empty($errorMessage)):?>
							<div class='error_message'><?php echo $errorMessage?></div>
						<?php endif?>
					</td>
					<td><?php echo $numSlides?></td>
					<td>
  					
  					<?php if($permission_setting): // permission ?>					
						<a class="button-primary revgreen" href='<?php echo $editLink ?>' title=""><i class="revicon-cog"></i><?php _uge("Settings",REVSLIDER_TEXTDOMAIN)?></a>
					<?php endif; // end permission?>						
						<a class="button-primary revblue" href='<?php echo $editSlidesLink ?>' title=""><i class="revicon-pencil-1"></i><?php _uge("Edit Slides",REVSLIDER_TEXTDOMAIN)?></a>
						
					<?php if($permission): // permission ?>						
						<a class="button-primary revcarrot export_slider_overview" id="export_slider_<?php echo $id?>" href="javascript:void(0);" title=""><i class="revicon-export"></i><?php _uge("Export Slider",REVSLIDER_TEXTDOMAIN)?></a>
						<a class="button-primary revred button_delete_slider"id="button_delete_<?php echo $id?>" href='javascript:void(0)' title="<?php _uge("Delete",REVSLIDER_TEXTDOMAIN)?>"><i class="revicon-trash"></i></a>
						<a class="button-primary revyellow button_duplicate_slider" id="button_duplicate_<?php echo $id?>" href='javascript:void(0)' title="<?php _uge("Duplicate",REVSLIDER_TEXTDOMAIN)?>"><i class="revicon-picture"></i></a>
					<?php endif; // end permission?>
						
						<div id="button_preview_<?php echo $id?>" class="button_slider_preview button-primary revgray" title="<?php _uge("Preview",REVSLIDER_TEXTDOMAIN)?>"><i class="revicon-search-1"></i></div>
					</td>
	
				</tr>							
			<?php endforeach;?>
			
		</tbody>		 
	</table>

	<?php require_once self::getPathTemplate("dialog_preview_slider");?>


	